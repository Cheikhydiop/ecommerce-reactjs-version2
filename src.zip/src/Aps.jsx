import React from 'react'

function Aps() {
  return (
    <div className= "snap-mandatory scroll-smooth">
        <section className="h-screen snap-center scroll-my-96">home</section>
        <section className="h-screen snap-center scroll-my-96">home</section>
        <section className="h-screen snap-center scroll-my-96">home</section>
        <section className="h-screen snap-center scroll-my-96">home</section>
        <section className="h-screen snap-center scroll-my-96">home</section>
       

    </div>
  )
}

export default Aps