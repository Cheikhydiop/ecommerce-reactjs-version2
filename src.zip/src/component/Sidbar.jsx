

export function sidbar () {
  return (
    <div className='sidbar'></div>
  )
}
