import Buton from './Buton';
import './index.css';

function White() {
  return (
    <div className="hover:cursor-pointer  ">noire </div>
  )
}

export default White