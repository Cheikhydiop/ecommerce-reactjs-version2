

function Black() {
  return (
    <html>
   <p className="text-blue-500 hover:cursor-pointer">blue</p>

          
<img width="20" height="22" className="mt-1" src="soleil.png" alt="sun--v1"/>
        
    </html>
    
    
  )
}

export default Black