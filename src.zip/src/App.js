import './index.css'
import './App.css';


import './index.css'
import Section from './Section';
import { Link, NavLink, Outlet, Router, RouterProvider, createBrowserRouter } from 'react-router-dom';
import Arttile from './Arttile';
import Head from './Head';
import Skill from './Skill';
import Contact from './Contact';
import Mysid from './Mysid';
import Accueil from './Accueil';
import Lien from './Lien';




const r=createBrowserRouter([
  {
    path:'/',
    element:(<div>
      <Accueil/>
    </div>
     ) ,
    
  },
  {
    path:'/section',
    element: <Section></Section>,
  },
    {
      path:'/Skill',
      element:<div> <Mysid/> <br/><br/> <Skill/> </div>  
    }, 
    {
      path:'/Accueil',
      element:<Accueil/>
    }, 
    {
      path:'/contact',
      element:<div><Mysid/><br/><br/><br/><br/>  <Contact/></div> 
    }
   ])

  




function App() {

  return<div>
     <RouterProvider  router={r}/>
  </div>
  
}


export default App;
