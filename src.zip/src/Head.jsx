import { useState } from 'react';
import Navbar from './Navbar';
import { motion } from 'framer-motion';

function Head() {
    const [title, setTitle] = useState(true);
    const [image, setImage] = useState(false);

    return (
        <div className='container mx-auto p-4'>
            <div className='flex flex-col md:flex-row items-center justify-between '>
                <div className='flex items-center space-x-4'>
                    
                    <span className="text-white">Cheikh</span>
                </div>
                <nav className="mt-4 md:mt-0 text-white flex space-x-4">
                    <a href="#Accueil" className="hover:underline">Accueil</a>
                    <a href="#Skill" className="hover:underline">Skill</a>
                    <a href="#Projet" className="hover:underline">Projet</a>
                    <a href="#Contact" className="hover:underline">Contact</a>
                </nav>
            </div>
        </div>
    );
}

export default Head;
