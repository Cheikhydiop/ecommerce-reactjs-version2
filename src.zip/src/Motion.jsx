import React from 'react'
import {motion} from "framer-motion";
import { createBrowserRouter } from 'react-router-dom';
function Motion() {
  return (
    <div>
       <div >
          <div className='text-red-500'>10000</div>
        
          </div>
    </div>
  )
}

export default Motion