

function Link() {
    const items=["Contact","blog","Skill"];


  return (
    <div>
       <p>kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk</p>
    </div>
  )
}

export default Link