import React from 'react'

function fomer() {
  return (
    <div className="grid grid-cols-6">
        <input type="text"></input>
    </div>
  )
}

export default fomer