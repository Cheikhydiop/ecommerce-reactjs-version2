import React from 'react'
import Buton from './Buton'
import Mysid from './Mysid'
import Item from './Item'

function Sedbar() {
  return (
    <div className='side'>
     <section><Item/></section>
       <section id="Contact">Contact</section>
       <section id='Skill'>Skill</section>
       <section id='Project'>Project</section>
       <section>home</section>
       <section>home</section>
       <section>home</section>
        
    </div>
  )
}

export default Sedbar