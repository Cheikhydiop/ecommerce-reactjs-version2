const a: [string,number]=['tomate',5] 
const b : [string,number]=['tomate',5]


function merge<T  extends unknown[],U extends unknown[]>(a:T,b:U):[...T,...U]{
    return [...a,...b]
}